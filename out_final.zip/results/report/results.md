# Study Results — None
- Data dir: /Users/jordanheckler/conciousness_proxy_sim copy 6/discovery_results/phase33c_coop_meaning_20251016_053421/data
