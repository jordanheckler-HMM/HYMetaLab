# End-to-End Study Workflow — Quick Start Guide

**Last Updated:** 2025-10-16  
**Status:** ✅ Validated with Phase 33c

---

## Overview

This guide provides a standardized workflow for running, packaging, and sealing OpenLaws studies from execution through archival.

---

## Prerequisites

- Python 3.8+
- OpenLaws automation system (`openlaws_automation.py`)
- Study configuration file in `studies/*.yml`
- Replication packet tool (`tools/make_replication_packet.py`)

---

## Three-Command Workflow

### Step 1: Run Study

```bash
python openlaws_automation.py run --study studies/YOUR_STUDY_ID.yml
```

**What it does:**
- Executes parameter sweep across all seeds
- Generates results in `discovery_results/YOUR_STUDY_ID_TIMESTAMP/`
- Creates `summary.json`, `run_manifest.json`, and results CSV

**Expected output:**
- `✅ Completed N/N runs`
- Results directory path
- Hypothesis test summary

### Step 2: Create Replication Packet

```bash
python tools/make_replication_packet.py --study YOUR_STUDY_ID --zip out.zip
```

**What it does:**
- Packages study config + results + manifests
- Creates ZIP archive with metadata
- Automatically finds timestamped results directory

**Expected output:**
- `✅ Replication packet created: out.zip`
- Archive contents list

### Step 3: Generate Integrity Seal

```bash
shasum -a 256 out.zip
```

**What it does:**
- Computes SHA256 cryptographic hash
- Creates tamper-evident integrity seal

**Expected output:**
- 64-character hexadecimal hash
- `SHA256: <hash> out.zip`

---

## Full Example: Phase 33c

```bash
# 1. Run study (288 simulations)
python openlaws_automation.py run --study studies/phase33c_coop_meaning.yml

# 2. Package results
python tools/make_replication_packet.py --study phase33c_coop_meaning --zip out.zip

# 3. Seal with SHA256
shasum -a 256 out.zip
# Output: f7da29b3ff491cc39cbc12151e4aa59e5756cb7a3c90161bfe547147453a3c89  out.zip

# 4. Save checksum (optional)
echo "f7da29b3ff491cc39cbc12151e4aa59e5756cb7a3c90161bfe547147453a3c89  out.zip" > out.zip.sha256
```

**Runtime:** ~2-5 minutes (depends on parameter sweep size)

---

## Output Files

### Primary Deliverables

| File | Description | Size (typical) |
|------|-------------|----------------|
| `out.zip` | Complete replication packet | 10-50 KB |
| `out.zip.sha256` | Integrity checksum | <1 KB |

### Replication Packet Contents

```
out.zip
├── YOUR_STUDY_ID.yml          # Study configuration
├── metadata.json              # Package metadata
└── results/
    ├── *_results.csv          # Full simulation data
    ├── run_manifest.json      # Run-level metadata
    ├── summary.json           # Hypothesis test results
    └── report/
        └── results.md         # Human-readable summary
```

### Timestamped Results Directory

```
discovery_results/YOUR_STUDY_ID_YYYYMMDD_HHMMSS/
├── END_TO_END_STUDY_REPORT.md  # Comprehensive analysis (auto-generated)
├── *_results.csv               # Raw data
├── run_manifest.json           # Metadata
└── summary.json                # Test outcomes
```

---

## Verification

### Check Packet Integrity

```bash
echo "YOUR_SHA256_HASH  out.zip" | shasum -a 256 -c
```

**Expected output:**
```
out.zip: OK
```

### Inspect Packet Contents

```bash
unzip -l out.zip
```

### Extract and Explore

```bash
unzip out.zip -d extracted_study/
cd extracted_study/results/
head -20 *_results.csv
cat summary.json | python -m json.tool
```

---

## Post-Study Tasks

### 1. Archive Locally

```bash
mkdir -p results/archive/
cp out.zip results/archive/YOUR_STUDY_ID_$(date +%Y%m%d).zip
cp out.zip.sha256 results/archive/
```

### 2. Version Control

```bash
git add discovery_results/YOUR_STUDY_ID_TIMESTAMP/
git add results/archive/YOUR_STUDY_ID_*.zip*
git commit -m "Study complete: YOUR_STUDY_ID (ΔCCI=X.XX, Δhazard=Y.YY)"
git push
```

### 3. Upload to Zenodo

**Manual:**
1. Visit https://zenodo.org/deposit/new
2. Upload `out.zip` + `out.zip.sha256`
3. Fill metadata (title, authors, description, keywords)
4. Publish and copy DOI

**Automated (if Makefile configured):**
```bash
make publish_zenodo
```

### 4. Update Dashboard

```bash
python tools/metadashboard.py --refresh --study YOUR_STUDY_ID
```

### 5. Run Guardian Validation

```bash
python qc/guardian_v4/guardian_v4.py --validate --file discovery_results/YOUR_STUDY_ID_*/END_TO_END_STUDY_REPORT.md
```

---

## Interpreting Results

### Hypothesis Test Outcomes

The `summary.json` file contains hypothesis test results:

```json
{
  "hypothesis_test": {
    "mean_CCI_gain": 0.0282,
    "mean_hazard_delta": -0.0232,
    "metrics_met": [
      {"name": "mean_CCI_gain", "rule": ">= 0.03", "passed": false},
      {"name": "mean_hazard_delta", "rule": "<= -0.01", "passed": true}
    ],
    "all_passed": false
  }
}
```

**Classification:**
- `all_passed: true` → ✅ **VALIDATED** (both metrics met)
- `all_passed: false` → ⚠️ **PARTIAL** (some metrics met) or ❌ **UNDER REVIEW** (no metrics met)

### Parameter Effects

Check `parameter_effects` in `summary.json` to identify which parameters had the strongest influence:

```json
{
  "parameter_effects": {
    "epsilon": {
      "0.0011": 0.5635,
      "0.0012": 0.5645,  // ← Best for CCI
      "0.0013": 0.5655
    }
  }
}
```

Use this to refine parameter ranges for follow-up studies.

---

## Troubleshooting

### Issue: "Results directory not found"

**Symptom:**
```
⚠ Results directory not found: results/discovery_results/YOUR_STUDY_ID
```

**Fix:**
The tool automatically searches for timestamped directories in `discovery_results/`. If it still fails:

```bash
# Manually specify the timestamped directory
ls discovery_results/ | grep YOUR_STUDY_ID
# Copy the full directory name and update the tool or move the directory
```

### Issue: "Study file not found"

**Symptom:**
```
⚠ Study file not found: studies/YOUR_STUDY_ID.yml
```

**Fix:**
Ensure the study ID matches the YAML filename exactly (case-sensitive):

```bash
ls studies/*.yml | grep -i YOUR_STUDY_ID
```

### Issue: "SHA256 mismatch"

**Symptom:**
```
out.zip: FAILED
```

**Fix:**
The file was modified or corrupted. Re-run Step 2-3 to regenerate:

```bash
rm out.zip out.zip.sha256
python tools/make_replication_packet.py --study YOUR_STUDY_ID --zip out.zip
shasum -a 256 out.zip > out.zip.sha256
```

---

## Advanced: Custom Replication Packets

### Include Additional Files

Edit `tools/make_replication_packet.py` to add custom files:

```python
# Add after line 50
extra_files = ["README.md", "LICENSE", "docs/methodology.pdf"]
for file in extra_files:
    if Path(file).exists():
        shutil.copy(file, temp_dir / Path(file).name)
```

### Exclude Large Files

```python
# Exclude raw logs or debug files
shutil.copytree(study_results, temp_dir / "results", 
                ignore=shutil.ignore_patterns('*.log', 'debug_*'))
```

---

## Best Practices

### ✅ Do's

- **Run with multiple seeds** (≥4) for reproducibility
- **Save SHA256** checksum immediately after packaging
- **Archive both** `.zip` and `.sha256` files together
- **Document deviations** from preregistration in END_TO_END_STUDY_REPORT.md
- **Version control** timestamped results directories

### ❌ Don'ts

- **Don't modify** ZIP after generating SHA256
- **Don't delete** timestamped results directories until archived
- **Don't skip** SHA256 verification before upload
- **Don't commit** massive CSV files to git (use git-lfs or archive separately)
- **Don't run** studies without preregistration YAML

---

## Quick Reference Card

```
┌──────────────────────────────────────────────────────┐
│ END-TO-END STUDY WORKFLOW (3 commands)               │
├──────────────────────────────────────────────────────┤
│ 1. Run:     python openlaws_automation.py run \     │
│             --study studies/STUDY_ID.yml             │
│                                                      │
│ 2. Package: python tools/make_replication_packet.py\│
│             --study STUDY_ID --zip out.zip           │
│                                                      │
│ 3. Seal:    shasum -a 256 out.zip                   │
├──────────────────────────────────────────────────────┤
│ Outputs:                                             │
│   • out.zip              (replication packet)        │
│   • out.zip.sha256       (integrity seal)            │
│   • discovery_results/STUDY_ID_*/  (full data)       │
│   • END_TO_END_STUDY_REPORT.md (analysis)            │
├──────────────────────────────────────────────────────┤
│ Next Steps:                                          │
│   • Archive to results/archive/                      │
│   • Upload to Zenodo (get DOI)                       │
│   • Update MetaDashboard                             │
│   • Run Guardian validation                          │
└──────────────────────────────────────────────────────┘
```

---

## Changelog

- **2025-10-16:** Initial version validated with Phase 33c
- Created `tools/make_replication_packet.py`
- Tested with 288-run parameter sweep
- Confirmed timestamped directory detection
- Verified SHA256 integrity workflow

---

## Related Documentation

- **Study Configuration:** `studies/README_PHASE33.md`
- **OpenLaws Automation:** `openlaws_automation.py --help`
- **Zenodo Publishing:** `docs/integrity/Zenodo_Upload_Instructions.md`
- **Guardian Validation:** `qc/guardian_v4/README.md`
- **MetaDashboard:** `tools/metadashboard.py --help`

---

**Questions or issues?** Open a ticket or see `docs/troubleshooting/STUDY_WORKFLOW.md`

