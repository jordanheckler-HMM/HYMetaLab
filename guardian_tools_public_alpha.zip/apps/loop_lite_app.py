import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime

st.set_page_config(page_title="Reality Loop Lite", page_icon="🔄", layout="wide")

st.title("🔄 Reality Loop Lite")
st.markdown("**Interactive simulation of the Universal Resilience Law**")

st.sidebar.header("Parameters")
st.sidebar.info("""
**Universal Resilience Law:**
R ∝ (ε × CCI) / η

Where:
- **ε**: Energy coupling
- **CCI**: Collective Coherence Index
- **η**: Dissipation (friction)
""")

# Parameter sliders
epsilon = st.sidebar.slider("ε (Energy Coupling)", 0.0005, 0.0025, 0.001, 0.0001)
cci = st.sidebar.slider("CCI (Collective Coherence)", 0.0, 1.0, 0.5, 0.01)
eta = st.sidebar.slider("η (Dissipation)", 0.0001, 0.01, 0.001, 0.0001)

# Compute resilience
resilience = (epsilon * cci) / eta if eta > 0 else 0

# Display metrics
col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric("ε", f"{epsilon:.4f}")
with col2:
    st.metric("CCI", f"{cci:.3f}")
with col3:
    st.metric("η", f"{eta:.4f}")
with col4:
    st.metric("Resilience", f"{resilience:.3f}")

# Simulation over time
st.subheader("📈 Resilience Over Time")

time_steps = st.slider("Time Steps", 10, 100, 50)
noise = st.slider("Environmental Noise", 0.0, 0.2, 0.05, 0.01)

# Generate time series
np.random.seed(42)
t = np.arange(time_steps)
cci_series = cci + noise * np.random.randn(time_steps)
cci_series = np.clip(cci_series, 0, 1)
resilience_series = (epsilon * cci_series) / eta

# Plot
fig = go.Figure()
fig.add_trace(go.Scatter(x=t, y=resilience_series, mode='lines+markers', 
                         name='Resilience', line=dict(color='blue', width=2)))
fig.update_layout(
    title="Resilience Dynamics",
    xaxis_title="Time Step",
    yaxis_title="Resilience (R)",
    hovermode='x unified'
)
st.plotly_chart(fig, use_container_width=True)

# Statistics
st.subheader("📊 Statistics")
col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Mean Resilience", f"{np.mean(resilience_series):.3f}")
with col2:
    st.metric("Std Dev", f"{np.std(resilience_series):.3f}")
with col3:
    st.metric("Max", f"{np.max(resilience_series):.3f}")

# Export data
if st.button("📥 Download Data"):
    df = pd.DataFrame({
        'time': t,
        'cci': cci_series,
        'resilience': resilience_series
    })
    csv = df.to_csv(index=False)
    st.download_button(
        label="Download CSV",
        data=csv,
        file_name=f"resilience_sim_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        mime="text/csv"
    )

st.markdown("---")
st.markdown("**Reality Loop Lite** | HYMetaLab Simulation Suite")
